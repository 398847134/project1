<template>
  <div id="qepp">
    <div id='totop' v-if="showtotop" v-on:click="totop()"><img src="../assets/totop.png"></div>
    <header class="header">
      <div class='close1'>&lt;返回</div>
      <div class='close2'>关闭</div>
       企鹅拼拼
      <div class="more">●●●</div>
    </header>
    <main class="main">
      <div v-for="data in datas" :key="data.id" class="logo" @click="jump(data.goods_no)">
        <div v-if="data.goods_status===3||data.goods_status===2">
        <div v-if="ison(data.sale_end_time,data.sale_start_time)=='4'" class="count">
          <div>{{ hours(data.sale_end_time) }}</div>：<div>{{ munites(data.sale_end_time) }}</div>：<div>{{ seconds(data.sale_end_time) }}</div>后结束
        </div>
        <div v-if="stateend"></div>
          <img :src= 'data.goods_logo'>
        <div class="msg">
          <div class="ms1">
            {{ data.goods_name }}
          </div>
          <div class="ms2">
            {{ data.goods_desc }}
          </div>
          <div class="ms3">
            <div class="price">￥{{ data.cur_price }}</div>
            <div class="original">{{ data.original_price }}</div>
            <button v-if="data.goods_status===3">暂停售卖</button>
            <button v-if="ison(data.sale_end_time,data.sale_start_time)=='3' || ison(data.sale_end_time,data.sale_start_time)=='4' && data.goods_status===2" :class="{pintuanbt:statestart}" @click="buy">火速拼团</button>
            <button v-if="ison(data.sale_end_time,data.sale_start_time)=='1'" :class="{endbt:stateend}">活动{{ days(data.sale_start_time) }}天后开始</button>
            <button v-if="ison(data.sale_end_time,data.sale_start_time)=='2'">{{ hours(data.sale_end_time) }}:{{ munites(data.sale_end_time) }}:{{ seconds(data.sale_end_time) }}后开始</button>
            <button v-if="ison(data.sale_end_time,data.sale_start_time)=='5' && data.goods_status===5" :class="{endbt:stateend}">停止售卖</button>
          </div>
          <div class="ms4" v-if="data.purchase_records_count>0">
            <div class="ms4left">

              <img :src='data.user.user_avatar'>
              <div>{{ data.user.user_nick }}  已拼团</div>
            </div>
            <div class="ms4right">
              <div>{{data.purchase_records_count}} 人已经抢购</div>
            </div>
          </div>
          <div class="ms5">
            <div>过期可退款</div>
            <div v-if="data.group_peoples > 0">{{data.group_peoples}}人团</div>
          </div>
        </div>
      </div>
      </div>
      <div v-if='shownomore' class="footer">{{more}}</div>
    </main>

  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'Qepp',
  data () {
    return {
      page: 1, // 当前页码
      now: null, // 当前时间
      statestart: true, // 开始抢购的class绑定
      stateend: false, // 停止抢购后的class绑定
      datas: null, // 后端数据
      status: null, // 状态码
      nextpath: null, // 判断是否加载下一页数据
      shownomore: false, // 控制上拉到底时显示下方文字
      more: null, // 上拉到底时的文字内容
      showtotop: false // 控制回到顶部的图标显示
    }
  },
  methods: {
    buy: function () {
      this.$router.push({
        name: 'Buying'
      })
    },
    jump: function (no) {
      this.$router.push({
        name: 'Xq',
        query: {
          id: no
        }
      })
    },
    totop: function () {
      // 当前显示的高度
      let scrollTop = document.documentElement.scrollTop
      // 回到顶部的动画
      let inter = setInterval(() => {
        scrollTop = scrollTop / 5
        document.body.scrollTop = document.documentElement.scrollTop = scrollTop
        // 到顶后动画结束
        if (scrollTop <= 1) {
          document.body.scrollTop = document.documentElement.scrollTop = 0
          clearInterval(inter)
        }
      }, 64)
      // 隐藏图标
      this.showtotop = false
    },
    onScroll: function () {
      // 可滚动容器的高度
      let innerHeight = document.querySelector('#app').clientHeight
      // 屏幕尺寸高度
      let outerHeight = document.documentElement.clientHeight
      // 可滚动容器超出当前窗口显示范围的高度
      let scrollTop = document.documentElement.scrollTop
      // 控制图标显示
      if (scrollTop > outerHeight / 2) {
        this.showtotop = true
      } else {
        this.showtotop = false
      }
      // scrollTop在页面为滚动时为0，开始滚动后，慢慢增加，滚动到页面底部时，出现innerHeight < (outerHeight + scrollTop)的情况，严格来讲，是接近底部。
      if (innerHeight < (outerHeight + scrollTop)) {
        // 加载更多操作
        if (this.nextpath == null) {
          this.more = '没有更多的数据了'
          this.shownomore = true
        } else {
          this.page += 1
          this.more = '正在加载'
          axios
            .get('http://uapi.qqmylife.com/v1/user/pinpin/goods?platform_id=2&page=' + this.page)
            .then(response => {
              this.datas = this.datas.concat(response.data.data.data)
              this.nextpath = response.data.data.next_page_url
            })
          this.shownomore = false
        }
      }
    },
    // 控制按钮显示状态码
    ison: function (ed, st) {
      let no = new Date().getTime()
      ed = ed * 1000
      st = st * 1000
      if (no - st < 0) {
        if (no - st + 86400000 < 0) {
          // 还没有开始
          return '1'
        } else if (no - st + 86400000 >= 0) {
          // 开始了，在一天以内，按钮倒计时
          return '2'
        }
      } else if (no - st > 0) {
        if (ed - no < 0) {
          // 已经结束
          return '5'
        } else if (ed - no > 0 && ed - no > 24 * 60 * 60 * 1000) {
          // 开始了，剩余时间大于一天
          return '3'
        } else if (ed - no > 0 && ed - no <= 24 * 60 * 60 * 1000) {
          // 开始了，剩余时间在一天以内
          return '4'
        }
      }
    }
  },
  mounted () {
    // 动态获取当前的时间
    setInterval(() => {
      this.now = new Date().getTime()
    }, 1000)
  },
  computed: {
    days: function () {
      return function (starttime) {
        return Math.floor(((starttime) * 1000 - (this.now)) / 3600000 / 24)
      }
    },
    hours: function () {
      return function (endtime) {
        return Math.floor(((endtime) * 1000 - this.now) / 3600000)
      }
    },
    munites: function () {
      return function (endtime) {
        return Math.floor(((endtime) * 1000 - this.now) % 3600000 / (1000 * 60))
      }
    },
    seconds: function () {
      return function (endtime) {
        return Math.round(((endtime) * 1000 - this.now) % 60000 / 1000)
      }
    }
  },
  created () {
    // 加载数据
    axios
      .get('http://uapi.qqmylife.com/v1/user/pinpin/goods?platform_id=2')
      .then(response => {
        this.datas = response.data.data.data
        this.nextpath = response.data.data.next_page_url
      })
      // 加载当前时间
    this.now = new Date().getTime()
    // 添加滚动事件监听
    window.addEventListener('scroll', this.onScroll)
  }

}
</script>

<style>
#totop{
  position:fixed;
  z-index: 999;
  right: 40px;
  bottom: 20px;
  background-color:rgba(133, 123, 123, 0.8);
  height: 90px;
  width: 90px;
  text-align: center;
  border-radius: 50%;
  line-height: 135px;
}
.footer{
  text-align: center;
  font-size: 31px;
  padding-bottom: 20px;
}
.price{
  font-size:28px;
  font-family:PingFangSC-Semibold;
  font-weight:600;
  color:rgba(242,46,58,1);
}
.original{
  text-decoration: line-through;
  font-size:24px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(153,153,153,1);
}
.ms3{
  height: 60px;
  padding-bottom: 20px;
}
.ms3 div{
  float: left;
  height: 60px;
  line-height: 60px;
  margin-left: 20px;
}

.ms3 button{
  border:0;
  float: right;
  width:230px;
  height:60px;
  border-radius:4px;
  font-size:26px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(255,255,255,1);
  line-height:26px;
}
.endbt{
  background-color:gray;
}
.pintuanbt{
  background:rgba(242,46,58,1);
}
.ms2{
  color: #f22e3a;
  width: 100%;
  font-size: 24px;
  margin: 20px 0;
  font-weight: 600
}
.main>div{
  margin-bottom: 24px;
  background-color: white;
}
.msg{
  width: 642px;
  margin: 0 auto;
}
.ms1{
  font-size: 28px;
  font-weight: 700;
  width: 100%
}
.buttonItem{
  margin:15px 10px;
  background-color: #fff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 10px;
  border:1px solid #ddd;
}
input{
    height: 45px;
    font-size: 1rem;
    padding-left:10px;
    border:0;
    outline: none;
}

.sendCode{
    border: 0;
    outline: none;
    background-color: #fff;
    cursor: pointer;
}
.main{
  margin-top: 13px;
  background-color: #f2f2f2;
  width: 96%;
  margin-left: 2%;
  position: relative;

}
.logo img{
  height:auto;
  width: 100%;

}
.more{
  position: absolute;
  right: 30px;
  top: 0;
  font-size: 20px;
}
.back{
  position: absolute;
  left: 10px;
  top: 0;
}
body{
  margin: 0;
  padding: 0;
  background-color: #f2f2f2;
}
.count{
  position: absolute;
  font-weight: 900;
  background-color: rgba(0,0,0,0.5);
  height: 78px;
  width: 285px;
  border-bottom-right-radius: 20px;
  text-align: center;
  line-height: 80px;

  font-size:24px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(255,255,255,1);
}
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
.header{
  width: 100%;
  height: 88px;
  background-color: #f2f2f2;
  position: relative;
  top: 0;
  line-height: 88px;
  font-size:37px;
  font-family:PingFangSC-Medium;
  font-weight:500;
  color:rgba(0,0,0,1);
  text-align: center;
  border-bottom: 1px solid #e5e5e5;
}
.header a{
  text-decoration: none;
  color: black;
  font-weight: 500;
  font-size: 21px;
}
.ms4{
  width: 100%;
  height:70px;
  background:rgba(249,249,249,1);
  line-height: 70px;
}
.ms4left{
  display: flex;
  align-items: center;
  float: left;
}
.ms4 div{
  font-size:24px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(153,153,153,1);
  margin-left:10px;
}
.ms4 img{
  width:36px;
  height:36px;
  border:1px solid rgba(235,235,235,1);
  border-radius: 50%;
  margin-left: 20px;
  float: left;
}
.ms4right{
  float: right;
  font-size:26px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(68,68,68,1);
  margin-right:20px;
}
.ms5{
  margin-top: 20px;
}
.close1{
  position: absolute;
  left:20px;
  font-size:32px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(0,0,0,1);
}
.close2{
  position: absolute;
  left:133px;
  font-size:32px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(0,0,0,1);
}
.ms5 div{
  display: inline-block;
  height:42px;
  border-radius:21px;
  border:1px solid rgba(153,153,153,1);
  font-size:22px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(153,153,153,1);
  padding: 6px 20px;
  line-height: 42px;
  margin-bottom: 20px;
  margin-right: 20px;
}
.count div{
  height: 36px;
  width: 44px;
  display: inline-block;
  background-color: white;
  color: black;
  vertical-align: middle;
  line-height: 36px;
  opacity: 1;
  margin-top: -2px;
}
</style>
