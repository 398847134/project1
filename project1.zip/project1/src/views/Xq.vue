<template>
<div>
  <div v-if="goodsstatus!=2 && alt" class="tanchuang">
    <div class="alet">
      <div class="boxclear">
        <img src="../assets/box.png">
      </div>

      <div class="saled">
        亲，宝贝已暂停售卖，快去看看其他好物
      </div>
      <div class="backbt" @click="goback">
        逛逛其他拼团
      </div>
    </div>
    <div class="chacha" @click="closealert">
      <img src="../assets/icon-close.png">
    </div>
  </div>
    <div>
        <div id='swiper_img_box'>
          <transition-group name='image' tag="ul" class="swiper_img_ul">
            <li v-for="(pic,index) in pics" :key="pic" v-show="index==showpic" @touchstart="stop" @touchend="start">
              <img :src="pic" @touchmove="change" @touchstart="getposition" @touchend="turn">
            </li>
          </transition-group>
          <ul class='buttonG' v-if=" pics.length > 1">
            <span  v-for='(img,index) in pics' :key='index' v-bind:class="{'checked':showpic==index}"></span>
          </ul>
        </div>
        <div class='saleend' v-if="goodsstatus!=2">
          <img src="../assets/saled.png">
        </div>
        <div class="prices">
          <div class="leftyuan">￥</div><div class="singleprice">{{singlePrice}}</div>
          <div>
            <div class="qgz">抢购中</div>
            <div class="original_price">￥{{orgpeice}}</div>
          </div>
          <div class="purchase_records_count" v-if="boughtcont>0">{{boughtcont}}人已购买</div>
        </div>
        <div class="title">
          <div class="titlemain">
            <div class="titles">{{goodsname}}</div>
            <div class=titledes>{{goodsms}} </div>
            <div class="preview">
              <a href="#" class="lefta">随时约</a><a href="#">随时退</a>
            </div>
          </div>
        </div>
        <div class="mendian">
          <div class="mdtop">适用门店<a href="#" @click="allstores">查看所有分店</a></div>
          <div class="mdbottom">
            <div class="bottomleft">
              <div class="mendiantop">{{mendian1}}</div>
              <div class="mendianbottom"><img src="../assets/icon-address.png">{{ address1 }}</div>
            </div>
            <div class="bottomright"><img src="../assets/icon-phone.png"></div>
          </div>
        </div>
        <div class="yhxq">
          <div class="yhxqmain">
            <div class="yhxqtt">优惠详情</div>
            <div class="yigang"></div>
          </div>
          <div v-html="goodsxq"></div>
        </div>
    </div>
    <div class="coun">
      <div class="jian" @click="jian">-</div>
      <div class="cno">
        <div class="floatno1">{{ bought }}</div>
        <div class="floatno2">数量</div>
      </div>
      <div class="jiahao" @click="add">+</div>
    </div>
    <div class="pt"><img src="../assets/51pt.png"></div>
    <div class="footer">
      <img src="../assets/icon-home.png">
      <img src="../assets/icon-phone.png">
      <div class="redbt" v-if="goodsstatus==2">
        <div class="money">{{ allprice }}</div>
        <div class="ljqg">立即抢购</div>
      </div>
      <div class="gray" v-else-if="goodsstatus!=2">
        <div class="stops">暂停售卖</div>
      </div>
    </div>
</div>
</template>
<style>
.chacha img{
  height: 100px;
  width: 100px;
  position: absolute;
  margin-top: 240px;
  left:325px;
}
.backbt{
  background-color: red;
  position: absolute;
  bottom: 0;
  width: 100%;
  height:100px;
  border-bottom-left-radius: 20px;
  border-bottom-right-radius: 20px;
  line-height: 100px;
  font-size:32px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(255,255,255,1);
}
.saled{
  width: 330px;
  font-size:30px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  margin: 0 auto;
}
.boxclear img{
  height:220px;
  width: 220px;
  margin-top:160px;
}
.alet{
  text-align: center;
  height: 700px;
  width: 580px;
  background-color: white;
  position: relative;
  left: 85px;
  top: 163px;
  border-radius:20px;
}
.tanchuang{
  z-index: 999;
  background:rgba(0,0,0,0.8);
  position: fixed;
  margin: 0;
  padding: 0;
  height: 100%;
  width: 100%;
}
.stops{
  font-size:36px;
  font-family:PingFangSC-Semibold;
  font-weight:600;
  color:rgba(255,255,255,1);
}
.gray{
  width: 495px;
  float: right;
  text-align: center;
  height:110px;
  background:rgba(153,153,153,1);
  line-height: 110px;
}
.saleend{
  position: absolute;
  top: 0;
}
.pt img{
  width:480px;
  height:90px;
}
.pt{
  margin-top: 40px;
  padding-bottom: 250px;
  text-align: center;
}
.jiahao{
  float: right;
  height: 60px;
  width: 60px;
  background:rgba(235,235,235,1);
  text-align: center;
  font-weight: 800;
  margin-top: 10px;
}
.floatno2{
  font-size:18px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(153,153,153,1);
}
.floatno1{
  font-size:36px;
  font-family:PingFangSC-Semibold;
  font-weight:600;
  color:rgba(68,68,68,1);
}
.cno{
  float: left;
  height: 60px;
  width: 60px;
  text-align: center;
  margin-left: 30px;
}
.jian{
  float: left;
  height: 60px;
  width: 60px;
  background:rgba(235,235,235,1);
  text-align: center;
  font-weight: 800;
  margin-top: 10px;
}
.coun{
  position: fixed;
  right: 40px;
  bottom: 130px;
  width: 240px;
  height: 80px;
  box-shadow:0px 8px 15px 0px rgba(0,0,0,0.2);
  border-radius:4px;
  background-color: white;
}

.ljqg{
  font-size:28px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(255,255,255,1);
}
.money{
  font-size:36px;
  font-family:PingFangSC-Semibold;
  font-weight:600;
  color:rgba(255,255,255,1);
}
.redbt{
  background-color:red;
  width: 495px;
  float: right;
  text-align: center;
  height:110px;
}
.footer img{
  height: 110px;
  width: 120px;
  border-right:  rgba(214,214,214,1) 1px solid;
}
.footer{
  position: fixed;
  bottom: 0;
  width: 100%;
  background-color: white;
  height: 110px;
  padding-bottom: 0;
}
.yigang{
  width:60px;
  height:8px;
  background:rgba(235,235,235,1);
  margin: 30px auto;
}
.yhxqtt{
  padding-top: 34px;
  text-align: center;
  font-size:30px;
  font-family:PingFangSC-Semibold;
  font-weight:600;
  color:rgba(34,34,34,1);
}
.yhxqmain{
  width: 95%;
  margin-left: 2.5%;
}
.yhxq{
  width: 100%;
  margin-top: 20px;
  background-color: white
}
.bottomright{
  position: absolute;
  right:25px;
  top: 35px;
}
.bottomright img{
  height:90px;
  width: 90px;
}
.mendianbottom img{
  height:32px;
  width: 32px;
}
.mendianbottom{
  font-size:26px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(153,153,153,1);
  width: 550px;
}
.bottomleft{
  width: 570px;
  border-right: rgba(214,214,214,1) 1px solid;
}
.mdbottom{
  width: 95%;
  margin-left: 2.5%;
  position: relative;
  border-top: rgba(214,214,214,1) 1px solid;
  padding-top:40px;
}
.mendiantop{
  font-size:28px;
  font-family:PingFangSC-Medium;
  font-weight:600;
  color:rgba(34,34,34,1);
}
.mdtop a{
  float: right;
  text-decoration: none;
  font-size:30px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(246,133,47,1);
}
.mdtop{
  font-size:30px;
  font-family:PingFangSC-Semibold;
  font-weight:600;
  color:rgba(34,34,34,1);
  line-height:30px;
  width: 95%;
  margin-left: 2.5%;
  height: 100px;
  line-height: 100px;
}
.mendian{
  margin-top: 20px;
  height: 250px;
  width: 100%;
  background-color: white;
}
.lefta{
  padding-right: 40px;
}
.preview a{
  text-decoration: none;
  font-size:28px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(153,153,153,1);
  line-height:28px;
}
.preview{
  border-top:2px solid rgba(214,214,214,1);
  color: #999999;
  margin-top: 67px;
  height: 100px;
  line-height: 100px;
}
.titledes{
  margin-top:20px;
  height:28px;
  font-size:28px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(242,46,58,1);
  line-height:28px;
}
.titles{
  padding-top: 50px;
  height:36px;
  font-size:36px;
  font-family:PingFangSC-Semibold;
  font-weight:600;
  color:rgba(34,34,34,1);
  line-height:36px;
}
.titlemain{
  width: 95%;
  height: 100%;
  margin-left: 2.5%;
}
.title{
  height:300px;
  width: 100%;
  background-color: white;
  margin: 0;
}
.purchase_records_count{
  position: absolute;
  font-size: 30px;
  font-weight: 800;
  right: 30px;
  top: 45px;
}
.original_price{
  margin-top: 50px;
  margin-left: -100px;
  height: 24px;
  font-size:24px;
  text-decoration:line-through;
}
.qgz{
  border: 1px solid white;
  margin-top: 20px;
  height: 22px;
  border-radius: 8px;
  font-size:20px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  line-height:22px;
  padding: 5px 5px;
}
.leftyuan{
  margin-top: 32px
}
.singleprice{
  font-size: 72px
}
.prices div{
  float: left;
  color: white
}
.prices{
  position: relative;
  background-color: red;
  height: 110px;
  width: 100%;
  border-top-left-radius: 15px;
  border-top-right-radius: 15px;
}

body{
  margin: 0;
  padding: 0;
  background-color: #f2f2f2;
}
img{
  width: 100%;
}
ul{
  list-style: none;
  overflow: hidden;
  height: 500px;
  margin: 0;
  padding:0;
}
.image-enter-active {
  transform: translateX(0);
  transition: all 1s ease;
}

.image-leave-active {
  transform: translateX(-100%);
  transition: all 1s ease;
}

.image-enter {
  transform: translateX(100%)
}

.image-leave {
  transform: translateX(0)
}
li{
  width: 100%;
  float: left;
}
.swiper_img_ul{
  height:562px;
}
.swiper_img_ul img{
  position:absolute;
}
#swiper_img_box{
  position:relative;
  width:100%;
  height:562px;
  overflow:hidden;
}
.buttonG{
  position:absolute;
  bottom:5px;
  left: 40%;
  height: 100px;
}
.buttonG span{
  font-size: 50px;
  line-height: 900px;
  background-color: rgba(255, 255, 255, 0.7);
  border:solid 0.5px black;
  height: 20px;
  width: 20px;
  display: inline-block;
  border-radius: 50%;
  margin: 0 5px;
}
.circle{
  display:inline-block;
  width:15px;
  height:15px;
  border-radius:100%;
  margin-left:10px;
}
.checked{
  background-color:rgba(0, 0, 0,0.7) !important;
}

</style>

<script>
import axios from 'axios'
export default {
  name: 'Xq',
  data () {
    return {
      datas: null, // 请求数据
      pics: [], // 轮播图片
      showpic: 0, // 控制图片是否显示
      positionX: 0, // 鼠标点击的坐标
      moveposition: 0, // 移动的当前坐标
      singlePrice: 0, // 单价
      goodsstatus: 2, // 物品在售状态
      orgpeice: 0, // 原价
      boughtcont: 0, // 已购人数
      goodsname: null, // 商品名
      goodsms: null, // 商品描述
      mendian1: null, // 首页门店名
      address1: null, // 首页门店地址
      bought: 1, // 购买数量
      stores: null, // 所有店铺的信息
      goodsxq: null, // 详情信息
      alt: true // 控制弹窗展示
    }
  },
  computed: {
    allprice: function () {
      return (this.bought * this.singlePrice).toFixed(2)
    }
  },
  mounted () {
    this.timer = setInterval(this.changeIndex, 5000)
  },
  methods: {
    /** *滑动限制***/
    slidestop () {
      var mo = function (e) { e.preventDefault() }
      document.body.style.overflow = 'hidden'
      document.addEventListener('touchmove', mo, false)// 禁止页面滑动
    },
    /** *取消滑动限制***/
    slidemove () {
      var mo = function (e) { e.preventDefault() }
      document.body.style.overflow = ''// 出现滚动条
      document.removeEventListener('touchmove', mo, false)
    },
    closealert () {
      this.alt = false
      this.slidemove()
    },
    goback () {
      this.slidemove()
      this.$router.push({
        name: 'Qepp',
        query: {

        }
      })
    },
    allstores () {
      this.$router.push({
        name: 'Allstores',
        query: {
          stores: this.stores
        }
      })
    },
    add () {
      this.bought += 1
    },
    jian () {
      this.bought -= 1
      if (this.bought < 1) {
        this.bought = 1
      }
    },
    getposition (e) {
      this.positionX = e.changedTouches[0].clientX
    },
    changeIndex () {
      if (this.showpic >= this.pics.length - 1) {
        this.showpic = 0
      } else {
        this.showpic++
      }
    },
    stop () {
      clearInterval(this.timer)
    },
    start () {
      clearInterval(this.timer)
      this.timer = setInterval(this.changeIndex, 5000)
    },
    goto (i) {
      this.showpic = i
      this.stop()
      this.start()
    },
    change (e) {
      this.moveposition = e.changedTouches[0].clientX
    },
    turn (e) {
      let ta = this.moveposition - this.positionX
      if (ta > 0) {
        if (ta > window.screen.width / 2) {
          this.goto(this.showpic - 1)
        }
      } else {
        if (-ta > window.screen.width / 2) {
          this.goto(this.showpic + 1)
        }
      }
    }
  },
  created () {
    axios.get('http://uapi.qqmylife.com/v1/user/pinpin/goods/detail?goods_no=' + this.$route.query.id + '&platform_id=2&sale_id=2').then(Response => {
      this.datas = Response.data.data
      this.pics = Response.data.data.goods_overview
      this.singlePrice = this.datas.single_purchase_price
      this.imgsLens = this.pics.length
      this.goodsstatus = this.datas.goods_status
      this.orgpeice = this.datas.original_price
      this.boughtcont = this.datas.purchase_records_count
      this.goodsname = this.datas.goods_name
      this.goodsms = this.datas.goods_desc
      this.mendian1 = this.datas.solutions[0].stores[0].sub_org_name
      this.address1 = this.datas.solutions[0].stores[0].address
      this.stores = this.datas.solutions[0].stores
      this.goodsxq = this.datas.goods_detail
      if (this.goodsstatus !== 2) {
        this.slidestop()
      }
      console.log(this.datas)
    })
  }
}

</script>
