<template>
<div>
 <swiper :options="swiperOption" ref="imgOverview" style="height:100%">
  <swiper-slide v-for="(img, index) in previewImg" :key="index">
    <div class="swiper-zoom-container">
      <img :src="img" alt="">
    </div>
  </swiper-slide>
</swiper>
<div>测试一下</div>
</div>

</template>
<style>

</style>

<script>
import {swiper, swiperSlide} from 'vue-awesome-swiper'
export default {
  name: 'Buying',
  data () {
    return {
      datas: null,
      swiperOption: {
        width: window.innerWidth,
        zoom: true,
        initialSlide: 0
      },
      previewImg: ['../assets/icon-close.png', '../assets/51pt.png', '../assets/saled.png']
    }
  },
  created () {

  },
  components: {
    swiper,
    swiperSlide
  }
}
</script>
<style>
img{
  height:100%;
  width:100%;
}
</style>
