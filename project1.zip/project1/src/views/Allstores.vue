<template>
    <div>
      <div v-for="(item, index) in datas.stores" :key="index">
        <div class="main">
          <div class="left">
          <div class="lefttop">
            {{ item.sub_org_name }}
          </div>
          <div class="leftbottom">
            <img src="../assets/icon-address.png">{{ item.address }}
          </div>
          </div>
          <div class="right">
            <img src="../assets/icon-phone.png">
          </div>
        </div>
      </div>

    </div>
</template>
<style>
.leftbottom{
  font-size:26px;
  font-family:PingFangSC-Regular;
  font-weight:400;
  color:rgba(153,153,153,1);
}
.lefttop{
  font-size:28px;
  font-family:PingFangSC-Medium;
  font-weight:800;
  color:rgba(34,34,34,1);
}
.lefttop,.leftbottom{
  height: 75px;
  line-height: 75px;
  margin-left: 24px;
}
.leftbottom img{
  height:30px;
  width: 30px;
}
.main{
  height: 150px;
  width: 100%;
  margin: 0;
  background-color: white;
  border-bottom: 1px solid #eee;
}
.left{
  float: left;
  height: 100%;
  margin: 0;
}
.main>div{
  margin: 0;
}
.right{
  float: right;
  height: 100%;
  border-left: #eee solid 1px;
}
body{
  padding: 0;
  margin: 0;
  background-color: white;
}
.right img{
  height: 120px;
  width: 120px;
  margin-top: 20px;
  margin-right: 10px;
}
</style>

<script>
export default {
  name: 'Allstores',
  data () {
    return {
      datas: null
    }
  },
  created () {
    this.datas = this.$route.query
    console.log(this.datas)
  }
}
</script>
