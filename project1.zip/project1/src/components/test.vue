<template>
  <div class="hello">
        <h1>组件路由测试</h1>
  </div>
</template>

<script>
export default {
  name: 'test',
  data () {
    return {

    }
  }
}
</script>
