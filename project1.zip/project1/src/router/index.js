import Vue from 'vue'
import Router from 'vue-router'
import Test from '../components/test'
import Qepp from '../views/Qepp'
import Xq from '../views/Xq'
import Allstores from '../views/Allstores'
import Buying from '../views/Buying'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      redirect: '/Qepp'
    }, {
      path: '/test',
      name: 'Test',
      component: Test
    }, {
      path: '/Qepp',
      name: 'Qepp',
      component: Qepp
    }, {
      path: '/Xq',
      name: 'Xq',
      component: Xq
    }, {
      path: '/Allstores',
      name: 'Allstores',
      component: Allstores
    }, {
      path: '/Buying',
      name: 'Buying',
      component: Buying
    }
  ]
})
