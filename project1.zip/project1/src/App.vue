<template>
  <div id="app">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    return {

    }
  },
  methods: {

  },
  mounted () {

  },
  computed: {

  },
  created () {

  }

}
</script>

<style>

</style>
